var fs = require('fs')
const http = require('http')

var stream;
var server;
var hostname = 'localhost';
port = 8080;

server = http.createServer();
server.on('request',function(req,res){
        var readStream = fs.createReadStream('./resources/SampleFile.exe');
        var writeStream = fs.createWriteStream('./resources/gradious-assignment.exe');
        readStream.on('data', function(chunk) {
            writeStream.write(chunk);
            console.log(chunk);
        });
        res.end("Chunks are successfully written to new .exe file!!!")
})

server.listen(port, hostname, () => {
	console.log(`Server running at http://${hostname}:${port}/`);
});