var fs = require('fs')
const http = require('http')

var stream;
var server;
var hostname = 'localhost';
port = 8080;

server = http.createServer();
server.on('request',function(req,res){
        stream = fs.createReadStream("./resources/sample.txt");
        res.statusCode = 200;
		stream.on("data", function(data) {
			var chunk = data.toString();
			console.log(chunk);
		});
})

server.listen(port, hostname, () => {
	console.log(`Server running at http://${hostname}:${port}/`);
});