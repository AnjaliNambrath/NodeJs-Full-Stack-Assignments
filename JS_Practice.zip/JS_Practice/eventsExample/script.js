function myFun() {
    const element = document.querySelector('#element');
  
    const toggleColor = (isEntering) => {
    element.style.background = isEntering ? 'orange' : 'yellow';
  };
  
  element.addEventListener('mouseover', () => toggleColor(true));
  element.addEventListener('mouseleave', () => toggleColor(false));
}

window.onload = myFun;