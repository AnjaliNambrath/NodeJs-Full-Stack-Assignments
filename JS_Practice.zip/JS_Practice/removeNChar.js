function removeChar(str,n) {
    // let str =[...str]
    var s=''
    for(let i=n;i<str.length;i++){
        s=s+str[i]
    }
    return s;
}
console.log(removeChar('abcd',2))