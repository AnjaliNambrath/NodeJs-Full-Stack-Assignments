this.name="chiru"
var fan=()=>{
    console.log(this.name)
}
fan()

 

//normal function
this.name="chiru"
function fan1(){
    console.log(this.name)
}
fan1()