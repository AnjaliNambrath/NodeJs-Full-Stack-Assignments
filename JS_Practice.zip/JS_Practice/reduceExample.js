// var arr = [5,3,2,5,7,1]
// var newArr = arr.reduce((tot,el) => tot+el)
// console.log(newArr);

// var arr = [1,4,2,5,3]
// var findSum = arr.reduce(function(tot,curr){
//     return tot+curr;
// },50)

// console.log(findSum);

// var arr = [2,8,3,9,1,5,6]
// const result = arr.reduce(function(max,curr){
//     if(curr>max){
//         max=curr
//     }
//     return max;
// },0)

// console.log(result);

// var arr = [2,5,1,9]

// const res = arr.reduce(((max,curr) => max>curr?max:curr),0)
// console.log(res);




const persons = [
  {firstname : "Anjali", lastname: "Nambrath",age:32},
  {firstname : "Priya", lastname: "Menon",age:23},
  {firstname : "Ram", lastname: "Kumar",age:35}
];

var newArr = persons.reduce(function(acc,curr){
    if(curr.age>30){
        acc.push(curr.firstname); 
    }
    return acc
},[]);

console.log(newArr);