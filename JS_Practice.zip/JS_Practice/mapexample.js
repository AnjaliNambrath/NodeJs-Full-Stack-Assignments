// const arr = [1,2,3,4,5]
// const square = arr.map(el => el*el);
// console.log(square);


// const a = [1,2,3,4,5]
// const sq = a.map(function (el){
//     return el*el;
// })

// console.log(sq)

const persons = [
  {firstname : "Anjali", lastname: "Nambrath",age:22,salary:20000},
  {firstname : "Priya", lastname: "Menon",age:33,salary:30000},
  {firstname : "Ram", lastname: "Kumar",age:35,salary:40000}
];



// var newPer = persons.map(item => item.firstname+" "+item.lastname)
// console.log(newPer);


var newArr = persons.filter(item => item.age>30).reduce((tot,item)=>{
  return tot+item.salary
},0)
console.log(newArr);


// const persons = [
//   {firstname : "Anjali", lastname: "Nambrath",age:19,salary:20000},
//   {firstname : "Priya", lastname: "Menon",age:23,salary:30000},
//   {firstname : "Ram", lastname: "Kumar",age:35,salary:40000}
// ];



// var newArr = persons.map(function(item) {
//   item.salary=item.salary+item.salary*(0.20)
//   return item;
// })
// console.log(newArr);

// var newArr = persons.filter(function(item){
//   if(item.age>20){
//   return item
//   }
// })

// var newArr = persons.reduce(function(tot,curr){
//     return tot+curr.salary
// },0)
// console.log(newArr);




// function getFullName(item) {
//   return [item.firstname,item.lastname].join(" ");
// }
// var newPer = persons.map(getFullName)
// console.log((newPer));

// var newPer = persons.map(item => [item.firstname,item.lastname].join(" "))
// console.log(newPer);


// var newPer = persons.map(function (item) {
//   return [item.firstname,item.lastname].join(" ");
// })
// console.log(newPer)