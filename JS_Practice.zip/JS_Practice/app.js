let a=23
let b="23";
console.log(a+ +b);