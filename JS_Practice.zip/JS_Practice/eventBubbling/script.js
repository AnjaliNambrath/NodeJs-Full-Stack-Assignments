

// var button = document.getElementById("but")
// console.log(button);
// button.addEventListener("click",function(){
//     alert('Hai')
// })


document.addEventListener('DOMContentLoaded', () => {
  const btn = document.getElementById('btn');
  btn.addEventListener('click', (event) => {
      event.stopPropagation();
    alert('You clicked the button');
  });


  var div = document.getElementById('div1')
div.addEventListener('click',function(){
  alert("div clicked")
})
var span = document.getElementById('span1')
span.addEventListener('click',function(event){
    event.stopPropagation();
  alert("span clicked")
})
});

