// var arr = [1,2,3,4,5]
// var newArr = arr.filter(el => el%2==0)
// console.log(newArr);

const persons = [
  {firstname : "Anjali", lastname: "Nambrath",age:22},
  {firstname : "Priya", lastname: "Menon",age:23},
  {firstname : "Ram", lastname: "Kumar",age:35}
];

var newArr = persons.filter(item => item.age<30)
console.log(newArr);