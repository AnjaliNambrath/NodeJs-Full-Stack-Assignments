function popB() {
  const li = document.querySelectorAll('#list li');
  console.log(li);
li.forEach(function(lis){
lis.addEventListener('mouseover',function(){
   lis.style.visibility = 'hidden';
})})
}
window.onload = popB;

// function popB() {
//   const li = document.querySelectorAll('#list li');
//   console.log(li);
//     li.addEventListener('mouseover',function(){
//    li.style.backgroundColor = 'red';
// })
// }
// window.onload = popB;

// const list = document.getElementById('list');
//   const handleHover = event => {
//     if(event.target !== list) {
//       event.target.style.visibility = 'hidden';
//     }
//   };
  
//   list.addEventListener('mouseover', handleHover);