var students = {
    "abhi@gmail.com":{
    "firstName": "Abhishek",
    "lastName": "Verma",
    "mobile": "9012345678",
    "age": 25,
    "city": "Delhi"
},
    "babu@gmail.com":{
    "firstName": "Babu",
    "lastName": "Annam",
    "mobile": "1012345678",
    "age": 20,
    "city": "Hyderabad"
},
    "chitra@gmail.com":{
    "firstName": "Chitra",
    "lastName": "Kumar",
    "mobile": "2012345678",
    "age": 22,
    "city": "Bangalore"
},

    "deepa@gmail.com":{
    "firstName": "Deepa",
    "lastName": "Verma",
    "mobile": "3012345678",
    "age": 27,
    "city": "Chennai"
    
},
    "savithasinik@gmail.com":{
        "firstName":"Savitha",
        "lastName":"Kutti",
        "mobile":"8525010997",
        "age":22 ,
         "city":"Chennai "
    },
    "sakthi@gmail.com":{
        "firstName":"Sakthi",
        "lastName":"Vengat",
        "mobile":"7648397632",
        "age":24 ,
         "city":" AndraPradesh"
    },
    "mathi@gmail.com":{
        "firstName":"Mathivathani",
        "lastName":"Bala",
        "mobile":"7659872534",
        "age": 29,
         "city":"Thiruvanamalai"
    },
    "pradeepa@gmail.com":{
        "firstName":"Pradeepa",
        "lastName":"Saravanan",
        "mobile":"6789453627",
        "age": 30,
         "city":" Vellore"
    },
    "priya@gmail.com":{
        "firstName":"Priya",
        "lastName":"Sekar",
        "mobile":"9835461027",
        "age":25 ,
         "city":"Krishnagiri "
    },
    "ezhil@gmail.com":{
        "firstName":"Ezhil",
        "lastName":"Kalyanasundharam",
        "mobile":"9234675856",
        "age":29 ,
         "city":"Virudhunagar "
    },
    "bhavya@gmail.com":{
        "firstName":"Bhavya",
        "lastName":"Shree",
        "mobile":"8796453728",
        "age":28 ,
         "city":"Thirupathi "
    },
    "anjalinambrath@gmail.com":{
        "firstName":"Anjali",
        "lastName":"Nambrath",
        "mobile":"93546789210",
        "age":26 ,
         "city":" Thiruvandram"
    },
    "ganesh@gmail.com":{
        "firstName":"Ganesh",
        "lastName":"Yazhan",
        "mobile":"8762563780",
        "age":28 ,
         "city":"Thiruvandram"
    },
    "balaji@gmail.com":{
        "firstName":"Balaji",
        "lastName":"Ram",
        "mobile":"9435678901",
        "age":24 ,
         "city":"Tamilnadu "
    },
    "divya@gmail.com":{
        "firstName":"divya",
        "lastName":"Malar",
        "mobile":"9875432240",
        "age":25 ,
         "city":"Tirupattur "
    },
    "savitha@gmail.com":{
        "firstName":"Savitha",
        "lastName":"Malar",
        "mobile":"8473627107",
        "age":22 ,
         "city":"Guindy"
    },
    "pugazhl@gmail.com":{
        "firstName":"Pugal",
        "lastName":"Kevin",
        "mobile":"9451837408",
        "age": 18,
         "city":"Pallavaram "
    },
    "nishali@gmail.com":{
      "firstName":"Nishali",
        "lastName":"Mega",
        "mobile":"8364728910",
        "age": 25,
         "city":"Karaipakkam "
    },
    "sowmiya@gmail.com":{
        "firstName":"Sowmiya",
        "lastName":"Vasu",
        "mobile":"9834567892",
        "age":23 ,
         "city":" Chennai"
    }  
}

localStorage.setItem("students", JSON.stringify(students));
var data = localStorage.getItem("students");
console.log("data: ", JSON.parse(data));

function loadData() {

    if(data!==null){
        var content = "<div class='table'><div class='header'><span class='cell'>FullName</span><span class='cell'>Age</span><span class='cell'>Mobile</span><span class='cell'>Email</span><span class='cell'>City</span></div>";
        for(let stud in students){
            //var email = Object.keys(students);
            content += "<div class='row'><span class='cell'>" + students[stud].firstName +" "+students[stud].lastName +"</span>";
            content += "<span class='cell'>" + students[stud].age + "</span>"
            content += "<span class='cell'>" + students[stud].mobile + "</span>"
            content += "<span class='cell'>" + stud + "</span>"
            content += "<span class='cell'>" + students[stud].city + "</span>"+"</div>"
    }
        console.log(content);
        var element =document.getElementById('container');
        element.innerHTML =content+"</div>";
    }
}

window.onload = loadData;

