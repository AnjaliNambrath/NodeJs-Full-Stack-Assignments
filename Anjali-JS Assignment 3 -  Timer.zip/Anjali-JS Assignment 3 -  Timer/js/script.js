var timer;
    var day = 0;
    var hr = 0;
    var min = 0;
    var sec = 0;
function setTimer() {
    day = document.getElementById('daysIn').value;
    hr = document.getElementById('hoursIn').value;
    min = document.getElementById('minsIn').value;
    sec = document.getElementById('secsIn').value;

    seconds = (Number(sec))+(Number(min)*60)+(Number(hr)*3600)+(Number(day)*(3600*24));
    day = Math.floor(seconds / (3600*24));
    hr = Math.floor(seconds % (3600*24) / 3600);
    min = Math.floor(seconds % 3600 / 60);
    sec = Math.floor(seconds % 60);
    document.getElementById('days').innerHTML = day<10 ? "0" + day :day;;
    document.getElementById('hours').innerHTML = hr<10 ? "0" + hr : hr;
    document.getElementById('mins').innerHTML = min<10 ? "0" + min : min;
    document.getElementById('secs').innerHTML = sec<10 ? "0" + sec :sec;
}

function countdown() {
    if(sec==0 && min==0 && hr==0 && day==0){
        alert("Times Up!!!")
        clearInterval(timer);
    }else{
        sec--;
        if(sec==-1){
            min--;
            sec=59;
            if(min==-1){
                hr--;
                min=59;
                if(hr==-1){
                    day--;
                    hr=23;
                }
            }
        }
    }
    let days=day<10 ? "0" + day :day;
    let hours= hr<10 ? "0" + hr : hr;
    let minutes=min<10 ? "0" + min : min;
    let seconds=sec<10 ? "0" + sec :sec;
    document.getElementById('days').innerHTML = days;
    document.getElementById('hours').innerHTML = hours;
    document.getElementById('mins').innerHTML = minutes;
    document.getElementById('secs').innerHTML = seconds;

}

function start(){
    clearInterval(timer)
    timer=setInterval(countdown,1000);
}

function stop(){
    clearInterval(timer);
}

function reset(){
    stop();
    document.getElementById('days').innerHTML = '00';
    document.getElementById('hours').innerHTML = '00';
    document.getElementById('mins').innerHTML = '00';
    document.getElementById('secs').innerHTML = '00';
    document.getElementById('daysIn').value = 0;
    document.getElementById('hoursIn').value = 0;
    document.getElementById('minsIn').value = 0;
    document.getElementById('secsIn').value = 0;
}