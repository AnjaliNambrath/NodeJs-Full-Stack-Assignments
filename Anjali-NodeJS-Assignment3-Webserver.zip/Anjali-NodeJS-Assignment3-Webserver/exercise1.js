const http = require('http');
const path = require('path');
const fs = require('fs')
const server = http.createServer();
fs.readFile('./lib/index.html',function (err,data) {
    if(err){
        throw err;
    }
    server.on('request',function (req,res) {
        res.writeHeader(200, {"Content-Type": "text/html"})
        res.write(data)
        res.end();    
    })
})

server.listen(8080, () => {
  console.log('Server running on http://localhost:8080');
});