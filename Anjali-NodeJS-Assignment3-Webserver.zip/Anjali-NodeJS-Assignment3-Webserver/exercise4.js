const express = require('express');

const app = express();
app.use(express.static('./public'));

app.listen(8080, () => {
  console.log('Server running on http://localhost:8080');
});

//http://localhost:8080 ->displays default index.html page