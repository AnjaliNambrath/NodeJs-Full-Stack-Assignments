const http = require('http');
const path = require('path');
const fs = require('fs')
const server = http.createServer();
fs.readFile('./lib/users.txt','utf8',function (err,result) {
    if(err){
        throw err;
    }
    server.on('request',function (req,res) {
        res.writeHeader(200, {"Content-Type": "text/html"})
        var data = result.split('\r\n').map(function(el){
         return el.split(/[|]/); 
        });
        var head = data.shift();
        var obj = data.map(function (el) {
        var obj = {};
        for (var i = 0;i < el.length; i++) {
            obj[head[i]] = el[i];
        }
        return obj;
        });
        var content = `<table border>
                        <tr>
                        <th>Name</th>
                        <th>Age</th>
                        <th>Gender</th>
                        <th>City</th>
                        </tr>`
            for(var i=0;i<obj.length;i++){
                content+=`<tr>
                        <td>${obj[i].Name}</td>
                        <td>${obj[i].Age}</td>
                        <td>${obj[i].Gender}</td>
                        <td>${obj[i].City}</td>
                        </tr>`
            }

        res.write(content+"</table>")
        res.end();    
    })
})

server.listen(8080, () => {
  console.log('Server running on http://localhost:8080');
});