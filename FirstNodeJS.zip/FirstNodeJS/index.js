const http = require('http');
const fs = require('fs');
const path = require('path');
const _ = require('lodash');
const server = http.createServer();
server.on('request', function(req, res){
	if (req.url === '/haiall') {
		res.writeHead(200);
		res.end('Hello All!');		
	}
	
});
server.listen(8080, () => {
  console.log('Server running on http://localhost:8080');
});