var status1,status2,status3,status4,status5;
function fnameValidation() {
     status1 = false;
                var fname = document.getElementById("fname").value;
                var rename=/[a-z]/ig;
                if (rename.test(fname)) {
                localStorage.setItem("Firstname", fname);
                status1 = true;
                } else {
                alert("Please enter valid first name");
                }
            }
function lnameValidation() {
    status2 = false;
                var lname = document.getElementById("lname").value;
                var rename=/[a-z]/ig;
                if (rename.test(lname)) {
                localStorage.setItem("LastName", lname);
                status2 = true;
                } else {
                alert("Please enter valid last name");
            }
            }
function emailValidation() {
    status3 = false;
                var useremail = document.getElementById("e").value;
                var re = /^[a-zA-Z0-9.-_]+@[a-zA-Z]+.[a-zA-Z]{2,}$/;
                if (re.test(useremail)) {
                localStorage.setItem("Email", useremail);
                status3 = true;
            }
            else {
                alert("Please enter valid emailid")
            }
            }
function phoneValidation() {
    status4 = false;
                var phn = document.getElementById("num").value;
                var rephn=/^[6-9]\d{9}$/;
                if (rephn.test(phn)) {
                localStorage.setItem("Phone", phn);
                status4 = true;
            }
            else {
                alert("Please enter valid phone number")
            }
            }
function positionValidation() {
    status5 = false;
                var pos = document.getElementById("pos").value;
                var rename=/[a-z]/ig;
                if (rename.test(pos)) {
                localStorage.setItem("Position", pos);
                status5 = true;
            } else {
                alert("Please enter valid position");
            }
            }


function validate() {
            fnameValidation();
            lnameValidation();
            emailValidation();
            phoneValidation();
            positionValidation(); 
            var gend = document.querySelector("input[name=gender]:checked").value;
            var city = document.getElementById("city").value;
            var startdate = document.getElementById("startd").value;
            var interdate = document.getElementById("interd").value;
            var time = document.querySelector("input[name=tim]:checked").value;
            localStorage.setItem("Gender",gend);
            localStorage.setItem("City",city);
            localStorage.setItem("Start Date",startdate);
            localStorage.setItem("Interview Date",interdate);
            localStorage.setItem("Time",time);
            console.log(status1);
            
            if(status1==true && status2==true && status3==true && status4==true && status5==true){
            alert("You have successfully applied for full stack developer job!")
        }
    }

        window.onload = function () {
            document.getElementById("fname").value=localStorage.getItem('Firstname')
            document.getElementById("lname").value=localStorage.getItem('LastName')
            document.getElementById("e").value=localStorage.getItem('Email')
            document.getElementById("num").value=localStorage.getItem('Phone')
            document.getElementById("pos").value=localStorage.getItem('Position')
            document.getElementById("city").value=localStorage.getItem('City')
            document.getElementById("startd").value=localStorage.getItem('Start Date')
            document.getElementById("interd").value=localStorage.getItem('Interview Date')
            var gendr = localStorage.getItem('Gender')
            const selected=document.querySelector(`input[type="radio"][value="${gendr}"]`)
            if(selected)
            {

                selected.checked=true;

            }
            var timesel = localStorage.getItem('Time')
            const select=document.querySelector(`input[type="radio"][value="${timesel}"]`)
            if(select)
            {

                select.checked=true;

            }
            // var time = localStorage.getItem('Time')
            // const select=document.getElementById(`[value="${time}"]`)
            // if(select)
            // {

            //    select.style.backgroundColor="blue";

            // }
        }

        // window.onload= function(){
        //     let sp= document.querySelectorAll('.but');
        //     //console.log(sp);
        //     // console.log(Array.isArray(sp));
        //     sp.forEach(s => {
        //     //s.style.backgroundColor = "";
        //     s.addEventListener('click', function (event) {
        //     // document.getElementById('time2').disabled=true;
        //     // console.log(event.target);
        //     // s.style.backgroundColor = "skyblue";
        //     var t = document.getElementById(`${event.target.id}`).innerHTML;
        //     document.getElementById(`${event.target.id}`).style.backgroundColor="skyblue";
        //     localStorage.setItem("Time",t);
        // })
        
        // });
        // }