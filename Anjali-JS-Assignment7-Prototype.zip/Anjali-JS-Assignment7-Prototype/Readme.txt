Instructions:

1. First I have created a Base class called Card which is having Properties like cardNumber and cardHolderName.
2. Then I have added a method using Prototype to the Parent class Card to check given amount is less than credit card limit.
3. After that I created two subclasses for Card class.CreditCard and DebitCard classes are inheriting from class Card.
4. By using Call method in subclasses, I can access the Parent class card methods and Properties. This is inheritance.
5. And I set CreditCard prototype and DebitCard prototype to be the instances of Card.
6. I implemented a method in DebitCard using prototype to check whether the account have balance to do payment.
7. Finally I created an Instance for Debitcard and Creditcard and i am accessing this methods using that created Object.

 
 Run this program using node card.js(filename)