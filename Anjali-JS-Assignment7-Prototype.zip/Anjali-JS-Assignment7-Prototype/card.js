//Card class
function Card(cardNumber,cardHolderName){
    this.cardNumber = cardNumber;
    this.cardHolderName = cardHolderName;
}

Card.prototype.calculateCreditLimit = function(){
    var myLimit = 160000;
    if(this.creditMoney>myLimit){
        console.log("Sorry! You dont have enough credit in your account to make payment")
    }else{
        console.log("You have successfully made the payment")
    }
}

//Creditcard class inheriting from Card
function CreditCard(cardNumber,cardHolderName,creditMoney){
    Card.call(this,cardNumber,cardHolderName)
    this.creditMoney = creditMoney;
}

//Set CreditCard prototype to be instance of Card
CreditCard.prototype = Object.create(Card.prototype);
CreditCard.prototype.constructor = CreditCard;


//Debitcard class inheriting from Card
function DebitCard(cardNumber,cardHolderName,debitMoney){
    Card.call(this,cardNumber,cardHolderName)
    this.debitMoney = debitMoney;
}


//Set DebitCard prototype to be instance of Card
DebitCard.prototype = Object.create(Card.prototype);
DebitCard.prototype.constructor = DebitCard;

DebitCard.prototype.calculateBalance = function(){
    var myBal = 200000;
    if(this.debitMoney>myBal){
        console.log("Sorry! You dont have enough money in your account to make payment")
    }else{
        console.log("You have successfully made the payment")
    }
}

//create an instance of CreditCard
var creditCard = new CreditCard(123456789123,"Saroop",20000)
creditCard.calculateCreditLimit();

//create an instance of DebitCard
var debitCard = new DebitCard(126678789123,"Aarohi",70000)
debitCard.calculateBalance();

