let prestatus = {
	1: "one",
	2: "two",
	3: "three",
	4: "four",
};

let users_json = [{
		userId: 1,
		name: "Jon Snow",
		profilePicture:
			"https://cg0.cgsociety.org/uploads/images/original/hosseindiba-jon-snow-1-b968195d-au6q.jpeg",
		statusMessage: "We become what we think about!",
		presence: 1,
	},
	{
		userId: 2,
		name: "Daenerys Targaryen",
		profilePicture:
			"https://preview.redd.it/hlxen8gtwpm01.jpg?width=640&crop=smart&auto=webp&v=enabled&s=a3c43bcbfc1db31d542ef67071559264358b3d2b",
		statusMessage: "A positive mindset brings positivethings.",
		presence: 3,
	},
	{
		userId: 3,
		name: "Tyrion Lannister",
		profilePicture:
			"https://mir-s3-cdn-cf.behance.net/project_modules/fs/6a3f5237411193.573f25019c8bf.jpg",
		statusMessage: "One small positive thought can change your whole day",
		presence: 3,
	},
	{
		userId: 4,
		name: "Jaime Lannister",
		profilePicture:
			"https://64.media.tumblr.com/21de4501827aba1c6463ce2ae6a36780/tumblr_ps5le9xxRb1w9a5vgo1_1280.jpg",
		statusMessage: "I am a rockstar",
		presence: 1,
	},
	{
		userId: 5,
		name: "Arya Stark",
		profilePicture:
			"https://64.media.tumblr.com/21de4501827aba1c6463ce2ae6a36780/tumblr_ps5le9xxRb1w9a5vgo1_1280.jpg",
		statusMessage: "I am using Gradious messenger",
		presence: 4,
}];

window.onload = display;
var form,upform;
function visibileUserForm(){
	form =document.getElementById('addUserForm');
	if (form.style.display === 'block') {
    form.style.display = 'none';
  } else {
    form.style.display = 'block';
  }
	
}

function clearform() {
	document.getElementById('name').value=""
	document.getElementById('profilePicLink').value="";
	document.getElementById('statusMessage').value="";
	document.getElementById('presence').value="1";
}

function clearUpdateform() {
	document.getElementById('upname').value="Name"
	document.getElementById('upprofilePicLink').value="Profile Picture Link";
	document.getElementById('upstatusMessage').value="Status Message";
	document.getElementById('presence').value="1";
}

function display() {
	var content = " "
	for(let user in users_json){
		var usr=`<div class="user">
				<div class="img-container">
					<img src="${users_json[user].profilePicture}" class="user-image ${prestatus[users_json[user].presence]}" alt="user image" />
				</div>
				<div class="user-detail">
				<p class="user-name">${users_json[user].name}</p>
				<p class="user-message">${users_json[user].statusMessage}</p>
				</div>
				<div class='three-btn'>
					<div class="dropdown">
						<a class="" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="bi bi-three-dots-vertical"></i></a>
						<ul class="dropdown-menu">
							<li><button id='${users_json[user].userId}' onclick='deleteItem("${users_json[user].userId}")' class="dropdown-item ">Delete</button></li>
							<li><button  id='update-${users_json[user].userId}' onclick='updateItem("${users_json[user].userId}")' class="dropdown-item ">Update</button></li>
						</ul>
					</div>
				</div>
			</div>`
	content = usr+content;
	}
	
	var element =document.getElementById('root');
    element.innerHTML =content;

}
	
console.log(users_json);
function addUser(){
	var username = document.getElementById('name').value;
	var dp = document.getElementById('profilePicLink').value;
	var sm = document.getElementById('statusMessage').value;
	var pre = document.getElementById('presence').value;
	console.log(username,dp,sm,pre);
	users_json.push({
		userId:users_json.length+1,
		name: username,
		profilePicture:dp,
		statusMessage: sm,
		presence: pre,
	})
	display();
	event.preventDefault();
	clearform();
	alert("User Added Successfully!!!")
	form.style.display = 'none';
}
let USERID;
function updateItem(usrId){
	upform =document.getElementById('updateUserForm');
	if (upform.style.display === 'block') {
    upform.style.display = 'none';
  } else {
    upform.style.display = 'block';
  }
  USERID=usrId;
  var ind = users_json.findIndex(e=> e.userId==usrId)
  console.log(ind);
  console.log(users_json[ind].name);
  	document.getElementById('upname').value = users_json[ind].name;
	document.getElementById('upprofilePicLink').value= users_json[ind].profilePicture;
	document.getElementById('upstatusMessage').value= users_json[ind].statusMessage;
}

function updateUser(){
	var upusername = document.getElementById('upname').value;
	var updp = document.getElementById('upprofilePicLink').value;
	var upsm = document.getElementById('upstatusMessage').value;
	var pre = document.getElementById('presence').value;
	console.log(upusername);
	var indx = users_json.findIndex(e=> e.userId==USERID)
	if(upusername==='' || updp==='' || upsm===''||pre===''){
		alert("Provide All the Details!!!")
		event.preventDefault();
		return;
	}
	users_json[indx].name = upusername;
	users_json[indx].profilePicture = updp;
	users_json[indx].statusMessage = upsm;
	users_json[indx].presence = pre;

	// users_json.push({
	// 	userId:users_json.length+1,
	// 	name: upusername,
	// 	profilePicture:updp,
	// 	statusMessage: upsm,
	// 	presence: pre,
	// })
	console.log(users_json);
	display();
	event.preventDefault();
	clearUpdateform();
	alert("Profile Updated Successfully!!!")
	upform.style.display = 'none';
}

function deleteItem(dltusr) {
	var delind = users_json.findIndex(e=> e.userId==dltusr);
	console.log(delind);
	delete users_json[delind];
	display();
}
