(function(KoreSDK){

    var KoreSDK=KoreSDK||{};

    var botOptionsWiz = {};
    botOptionsWiz.logLevel = 'debug';
    botOptionsWiz.koreAPIUrl = "https://bots.kore.ai";

    botOptionsWiz.JWTUrl = "PLEASE_ENTER_JWTURL_HERE";
    botOptionsWiz.userIdentity = 'anjalivnamrat@gmail.com';// Provide users email id here
    botOptionsWiz.botInfo = { name: "Admin Bot for Flight", "_id": "st-0bb12fff-e9ac-54b4-a839-6f259750fb09" }; // bot name is case sensitive
    botOptionsWiz.clientId = "cs-a93582f2-8539-559a-9df5-8eb4dd16be39";
    botOptionsWiz.clientSecret = "PLEASE_ENTER_CLIENT_SECRET";

    var widgetsConfig = {
        botOptions: botOptionsWiz
    };
    
    KoreSDK.widgetsConfig=widgetsConfig
})(window.KoreSDK);