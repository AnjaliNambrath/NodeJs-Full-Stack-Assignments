
// var restoken;
function userLogin(){
    var email = document.getElementById('email').value;
    var password = document.getElementById('password').value;
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function(){
        if(this.readyState==4){
            if(this.status==200){
                console.log("token");
                var restoken = JSON.parse(this.responseText);
                localStorage.setItem("token",JSON.stringify(restoken.token))
                checkUser(restoken)
            }
        }
    }
    xhttp.open("POST","http://localhost:5000/auth/sign_in",true)
    xhttp.setRequestHeader("Content-type","application/json")
    xhttp.send(JSON.stringify({email:email,password:password
    }))
    event.preventDefault();
}

function userRegister(){
    var name = document.getElementById('name').value;
    var emailid = document.getElementById('emailid').value;
    var pass = document.getElementById('pass').value;
    var xhhttp = new XMLHttpRequest();
    xhhttp.onreadystatechange = function(){
        if(this.readyState==4){
            if(this.status==200){
                
                location.href='/userlogin.html'
                alert('Successfully Registered, Plaese Sign In')
            }
        }
    }
    xhhttp.open("POST","http://localhost:5000/auth/register",true)
    xhhttp.setRequestHeader("Content-type","application/json")
    xhhttp.send(JSON.stringify({fullName:name,email:emailid,password:pass
    }))
    event.preventDefault();
}

function checkUser(restoken){
    var xxhttp = new XMLHttpRequest();
    xxhttp.onreadystatechange = function(){
        if(this.readyState==4){
            if(this.status==200){
                console.log("hai");
                var resp = JSON.parse(this.responseText)
                console.log(resp.email);
                if(resp.email=="admin@gmail.com"){
                    location.href='/index.html'
                }
                else{
                location.href='/booking.html'
                }
            }
        }
    }
    xxhttp.open("GET","http://localhost:5000/profile",true)
    // xxhttp.setRequestHeader("Content-Type","application/json")
    xxhttp.setRequestHeader('Authorization','JWT '+restoken.token)
    xxhttp.send()
    event.preventDefault();
}