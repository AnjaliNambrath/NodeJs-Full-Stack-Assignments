const url = 'mongodb://localhost:27017/FlightManagement'
module.exports = url