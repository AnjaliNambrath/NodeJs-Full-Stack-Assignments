const express = require('express')
const router = express.Router();

const flightController = require('../controllers/flight')
var userHandlers = require('../controllers/userController.js');
const routeController = require('../controllers/route');
const bookingController= require('../controllers/booking.js')

    router.get('/profile',userHandlers.loginRequired, userHandlers.profile)
    router.post('/auth/register',userHandlers.register)
   router.post('/auth/sign_in',userHandlers.sign_in)


router.post('/flight',flightController.createFlight)
router.get('/flight',flightController.getAllFlight)
// router.post('/login',loginController.loginUser)
router.put('/flight/:_id', flightController.updateFlight);
router.delete('/flight/:_id', flightController.deleteFlight);


router.get('/routes',routeController.getAllroutes);
router.post('/routes',routeController.addroutes);
router.get('/routes/:id',routeController.getrouteById);
router.put('/routes/:id',routeController.updateroute);
router.delete('/routes/:id',routeController.deleteroute);
router.get('/routes/:source/:destination',routeController.searchflight);


router.get('/searchflights',bookingController.getFlightDetails);
router.post('/customer',bookingController.createCustomer);
router.get('/searchCustomers', bookingController.getCustomerDetails);
router.delete('/customer/:id',bookingController.deleteCustomerDetail)


router.get('/sts',flightController.generateJWTForOTTBot);
router.get('/stsadmin',flightController.generateJWTForAdminBot);
module.exports = router;