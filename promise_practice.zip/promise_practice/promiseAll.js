var p1 = new Promise(function(resolve, reject){
	var req = new XMLHttpRequest();
	req.open("GET", "https://62d8035e90883139358919d0.mockapi.io/api/v1/users", true);
	req.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	req.send();
	req.onreadystatechange = function(){
		if(req.readyState == 4){
			if(req.status == 200){
				resolve(req.responseText);
			} else {
				reject("Failed");
			}
		}
	}
});
var p2 = new Promise(function(resolve, reject){
	var req = new XMLHttpRequest();
	req.open("GET", "https://62d8035e90883139358919d0.mockapi.io/api/v1/employees", true);
	req.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	req.send();
	req.onreadystatechange = function(){
		if(req.readyState == 4){
			if(req.status == 200){
				resolve(req.responseText);
			} else {
				reject("Failed");
			}
		}
	}
});
var p3 = new Promise(function(resolve, reject){
	var req = new XMLHttpRequest();
	req.open("GET", "https://62d8035e90883139358919d0.mockapi.io/api/v1/products", true);
	req.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	req.send();
	req.onreadystatechange = function(){
		if(req.readyState == 4){
			if(req.status == 200){
				resolve(req.responseText);
			} else {
				reject("Failed");
			}
		}
	}
});
Promise.all([p1, p2, p3]).then((data)=> {
    console.log("Users:::", data[0]);
    console.log("Employees:::", data[1]);
    console.log("Products:::", data[2]);
});