function sendRequest(url){
    return new Promise(function(resolve, reject){
    	var req = new XMLHttpRequest();
    	req.open("GET", "https://62d8035e90883139358919d0.mockapi.io/api/v1/users", true);
    	req.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    	req.send();
    	req.onreadystatechange = function(){
			if(req.readyState == 4){
				if(req.status == 200){
					resolve(req.responseText);
				} else {
					reject("Failed");
				}
			}
    	}
    });
}

async function display(){
  try{
    var users = await sendRequest("https://62d8035e90883139358919d0.mockapi.io/api/v1/usersAAA");
    console.log("@@@@@@@@@@@ USERS::::::::::::::::", JSON.parse(users));
    users = JSON.parse(users);
    var userId = users[5].userid;
    var user = await sendRequest("https://62d8035e90883139358919d0.mockapi.io/api/v1/users/" + userId);
    console.log("@@@@@@@@@@@ USER INFO ::::::::::::::::", JSON.parse(user));
  } catch(err) {
    console.log(err);
  }
}