function sendRequest(url){
    return new Promise(function(resolve, reject){
    	var req = new XMLHttpRequest();
    	req.open("GET",url, true);
    	req.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    	req.send();
    	req.onreadystatechange = function(){
			if(req.readyState == 4){
				if(req.status == 200){
					resolve(req.responseText);
				} else {
					reject("Failed");
				}
			}
    	}
    });
}
var url = "https://62d8035e90883139358919d0.mockapi.io/api/v1/users";
sendRequest(url).then((data)=> {
  var user = JSON.parse(data)[0];
  console.log(user);
  var url = "https://62d8035e90883139358919d0.mockapi.io/api/v1/users/"+user.userid;
  sendRequest(url).then((data)=> {
    console.log(JSON.parse(data));
  }).then(()=>{
    console.log("END")
  });
}).then(()=>{
  console.log("Hai")
});