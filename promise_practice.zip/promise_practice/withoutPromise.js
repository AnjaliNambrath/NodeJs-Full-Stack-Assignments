function sendRequest(url, method, data, callback){
	var req = new XMLHttpRequest();
	req.open(method, url, true);
	req.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	req.send();
	req.onreadystatechange = function(){
		if(req.readyState == 4){
          if(req.status == 200){
			// Response received for the first request
			//callback(null, JSON.parse(req.responseText));
			var userId = JSON.parse(req.responseText)[0].userid;
			var req2 = new XMLHttpRequest();
			req2.open(method, url+"/"+userId, true);
			req2.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
			req2.send();
			req2.onreadystatechange = function(){
				if(req2.readyState == 4){
				  if(req2.status == 200){
					var req3 = new XMLHttpRequest();
					req3.open(method, "https://62d8035e90883139358919d0.mockapi.io/api/v1/products", true);
					req3.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
					req3.send();
					req3.onreadystatechange = function(){
						if(req3.readyState == 4){
						  if(req3.status == 200){
							callback(null, JSON.parse(req3.responseText));
						  } else {
							callback("Failed", null);
						  }
						}
					}				  } else {
					callback("Failed", null);
				  }
				}
			}
          } else {
            callback("Failed", null);
          }
        }
	}
}
function userDetail(err, users){
	if(err){
		console.error(err);
	} else {
		console.log("#######USERS ::::::", users);
	}
}
var url = "https://62d8035e90883139358919d0.mockapi.io/api/v1/users";
sendRequest(url, "GET", null, userDetail);