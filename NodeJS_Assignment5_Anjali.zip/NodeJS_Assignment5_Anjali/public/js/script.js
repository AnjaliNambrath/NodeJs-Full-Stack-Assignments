let prestatus = {
	1: "one",
	2: "two",
	3: "three",
	4: "four",
};
var xhttp;
var count =6;
var users_json ="";


window.onload = display;
var form,upform;
function visibileUserForm(){
	form =document.getElementById('addUserForm');
	if (form.style.display === 'block') {
    form.style.display = 'none';
  } else {
    form.style.display = 'block';
  }
	
}

function clearform() {
	document.getElementById('name').value=""
	document.getElementById('profilePicLink').value="";
	document.getElementById('statusMessage').value="";
	document.getElementById('presence').value="1";
}

function clearUpdateform() {
	document.getElementById('upname').value="Name"
	document.getElementById('upprofilePicLink').value="Profile Picture Link";
	document.getElementById('upstatusMessage').value="Status Message";
	document.getElementById('presence').value="1";
}


function display() {
	var content = " "
	xhttp = new XMLHttpRequest();
    
    xhttp.onreadystatechange =function () {
        
        if(this.readyState == 4){
            if(this.status == 200){
            res = this.responseText;
            users_json=JSON.parse(res);
            // loadUser(res);
			for(let user in users_json){
		var usr=`<div class="user">
				<div class="img-container">
					<img src="${users_json[user].profilePicture}" class="user-image ${prestatus[users_json[user].presence]}" alt="user image" />
				</div>
				<div class="user-detail">
				<p class="user-name">${users_json[user].name}</p>
				<p class="user-message">${users_json[user].statusMessage}</p>
				</div>
				<div class='three-btn'>
					<div class="dropdown">
						<a class="" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="bi bi-three-dots-vertical"></i></a>
						<ul class="dropdown-menu">
							<li><button id='${users_json[user].userId}' onclick='deleteItem("${users_json[user].userId}")' class="dropdown-item ">Delete</button></li>
							<li><button  id='update-${users_json[user].userId}' onclick='updateItem("${users_json[user].userId}")' class="dropdown-item ">Update</button></li>
						</ul>
					</div>
				</div>
			</div>`
	content = usr+content;
	}
	
	var element =document.getElementById('root');
    element.innerHTML =content;
            
        }
    }
    };
    xhttp.open("GET","http://localhost:8080/buddylist",true)
    xhttp.send();

}
	
console.log(users_json);
function addUser(){
	var username = document.getElementById('name').value;
	var dp = document.getElementById('profilePicLink').value;
	var sm = document.getElementById('statusMessage').value;
	var pre = document.getElementById('presence').value;

	xhttp = new XMLHttpRequest();
 
    xhttp.onreadystatechange =function () {
        console.log(this.readState);
        console.log(this.status);
        if(this.readyState == 4){
            if(this.status == 200){
                //  console.log(this.responseText);               
                display();
            }
        }
    };
    xhttp.open("POST","http://localhost:8080/buddylist",true)
    xhttp.setRequestHeader("Content-type","application/json")
    xhttp.send(JSON.stringify({
		name: username,
		profilePicture:dp,
		statusMessage: sm,
		presence: pre
	}));
	event.preventDefault();
	// display();
	clearform();
	alert("User Added Successfully!!!")
	form.style.display = 'none';
}
let USERID;
function updateItem(usrId){
	upform =document.getElementById('updateUserForm');
	if (upform.style.display === 'block') {
    upform.style.display = 'none';
  } else {
    upform.style.display = 'block';
  }
  USERID=usrId;
  var ind = users_json.findIndex(e=> e.userId==usrId)
  console.log(ind);
  console.log(users_json[ind].name);
  	document.getElementById('upname').value = users_json[ind].name;
	document.getElementById('upprofilePicLink').value= users_json[ind].profilePicture;
	document.getElementById('upstatusMessage').value= users_json[ind].statusMessage;
	document.getElementById('uppresence').value= users_json[ind].presence;
}

function updateUser(){
	var upusername = document.getElementById('upname').value;
	var updp = document.getElementById('upprofilePicLink').value;
	var upsm = document.getElementById('upstatusMessage').value;
	var pre = document.getElementById('uppresence').value;
	if(upusername==='' || updp==='' || upsm===''||pre===''){
		alert("Provide All the Details!!!")
		event.preventDefault();
		return;
	}


	xhttp = new XMLHttpRequest();
 
    xhttp.onreadystatechange =function () {
        if(this.readyState == 4){
            if(this.status == 200){
                display();
            }
        }
    };
    xhttp.open("PUT","http://localhost:8080/buddylist/"+USERID,true)
    xhttp.setRequestHeader("Content-type","application/json")
    xhttp.send(JSON.stringify({
		name: upusername,
		profilePicture:updp,
		statusMessage: upsm,
		presence: pre
	}));

	console.log(users_json);
	display();
	event.preventDefault();
	clearUpdateform();
	alert("Profile Updated Successfully!!!")
	upform.style.display = 'none';
}

function deleteItem(dltusr) {
	var xxhttp = new XMLHttpRequest();
	xxhttp.open("DELETE","http://localhost:8080/buddylist/"+dltusr,true)
    xxhttp.send();
        xxhttp.onreadystatechange =function () {
            if(this.readyState == 4){
                if(this.status == 200){
                    display();
                }
            }
        };  
}
