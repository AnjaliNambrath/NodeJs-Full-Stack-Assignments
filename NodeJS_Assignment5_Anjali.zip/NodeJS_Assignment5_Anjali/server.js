const bodyParser = require('body-parser');
const express = require('express');
const fs = require('fs');

const app = express();
app.use('/',express.static('./public'));
app.use(bodyParser.json())

app.listen(8080, () => {
  console.log('Server running on http://localhost:8080');
});

//Define a route to serve the Buddy list Json
app.get('/buddylist',(req,res)=>{
    fs.readFile('./data/buddy-list.json','utf8',(err,data)=>{
        if(err){
            console.error(err);
            res.status(500).json({error:'Internal Server Error'})
        }else{

            res.status(200).json(JSON.parse(data))
        }
    })
})

app.post('/buddylist', (req, res) => {
        console.log("Method called is -- ", req.method)
        console.log("req",req.body);
        // var jsonObj = JSON.stringify(req.body);
        // console.log("json",jsonObj);
        var c = fs.readFileSync('./data/count.txt')
        c++;
        fs.writeFileSync('./data/count.txt',c.toString())
        console.log(c);
        req.body.userId=c;
        fs.readFile('./data/buddy-list.json', function (err, data) {
            var json = JSON.parse(data)
            json.push(req.body)
            console.log(json);
            fs.writeFile("./data/buddy-list.json", JSON.stringify(json,null,4).split('\\').join(''),function(err){
                if(err){
                    console.error(err);
                }else{
                fs.readFile('./data/buddy-list.json',(err,data)=>{
                    if(err){
                        console.error(err);
                        res.status(500).json({error:'Internal Server Error'})
                    }else{
                        res.send(data)
                        res.end()
                    }
                })
            }
        })
    })
})

app.put('/buddylist/:id', (req, res) => {
        console.log("Method called is -- ", req.method)
        // console.log("req",req.body);
        // var jsonObj = JSON.stringify(req.body);
        // console.log("json",jsonObj);

        fs.readFile('./data/buddy-list.json', function (err, data) {
            var usjson = JSON.parse(data)
            var recData = req.body
            var upind = usjson.findIndex(e=> e.userId==req.params.id);
                usjson[upind].name = recData.name
                usjson[upind].profilePicture = recData.profilePicture
                usjson[upind].statusMessage = recData.statusMessage
                usjson[upind].presence = recData.presence
            fs.writeFile("./data/buddy-list.json", JSON.stringify(usjson,null,4).split('\\').join(''),function(err){
                if(err){
                    console.error(err);
                }else{
                fs.readFile('./data/buddy-list.json',(err,data)=>{
                    if(err){
                        console.error(err);
                        res.status(500).json({error:'Internal Server Error'})
                    }else{
                        res.send(data)
                        res.end()
                    }
                })
            }
        })
    })
})

app.delete('/buddylist/:id',(req,res)=>{
    console.log("req",req.params.id);
       fs.readFile('./data/buddy-list.json', function (err, data) {
            var userjson = JSON.parse(data)
            var delind = userjson.findIndex(e=> e.userId==req.params.id);
            userjson.splice(delind,1)
            console.log(userjson);
            fs.writeFile("./data/buddy-list.json", JSON.stringify(userjson,null,4).split('\\').join(''),function(err){
                if(err){
                    console.error(err);
                }else{
                fs.readFile('./data/buddy-list.json',(err,data)=>{
                    if(err){
                        console.error(err);
                        res.status(500).json({error:'Internal Server Error'})
                    }else{
                        res.send(data)
                        res.end()
                    }
                })
            }
        })
    })
    // fs.readFile('./data/buddy-list.json','utf8',(err,data)=>{
    //     if(err){
    //         console.error(err);
    //         res.status(500).json({error:'Internal Server Error'})
    //     }else{
    //         res.send(data)
    //         res.end()
    //     }
    // })
})