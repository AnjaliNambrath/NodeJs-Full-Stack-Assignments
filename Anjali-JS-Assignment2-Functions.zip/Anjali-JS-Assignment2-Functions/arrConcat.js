var a1 = [1,2,3,4,5]
var a2 = [6,7,8,9]
function combineArr(a1,a2) {
    let k = a1.length;
    for(let i=0;i<a2.length;i++){
        a1[k]=a2[i];
        k++
    }
    return a1;

}
console.log(combineArr(a1,a2));