var arr=[1,2,3,4,5]
function unshiftArray(a,val) {
    for(let i=a.length;i>0;i--){
        a[i]=a[i-1]
    }
    a[0]=val
    console.log(a);
    return a.length;
}

console.log(unshiftArray(arr,10));