arr=[1,2,3,3,4,5,4]
function lastOccurrence(arr,val) {
    for(let i=arr.length;i>0;i--){
        if(arr[i]==val){
            return i;
        }
    }
    return -1;
}

console.log(lastOccurrence(arr,4));