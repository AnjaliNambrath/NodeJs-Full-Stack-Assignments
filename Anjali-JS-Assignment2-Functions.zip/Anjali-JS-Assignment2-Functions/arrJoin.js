var arr=["aaa",1,2,"ccc","ddd"]
function joinArray(arr) {
    let str = ""
    for(let i=0;i<arr.length;i++){
        if(i==arr.length-1){
        str=str+arr[i]
        }else{
            str=str+arr[i]+",";
        }
    }
    return str;
}

console.log(joinArray(arr));