arr=[1,2,3,4,5]
function popArray(arr) {
    var poparr=[]
    for(var i=0;i<arr.length-1;i++){
        poparr[i]=arr[i];
    }
    console.log(poparr);
    return(poparr.length)
}
console.log(popArray(arr));