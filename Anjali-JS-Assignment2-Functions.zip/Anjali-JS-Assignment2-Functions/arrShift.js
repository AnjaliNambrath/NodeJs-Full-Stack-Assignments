var arr=[1,2,3,4,5]
function shiftArray(a) {
    var temp=[]
    var j=0;
    for(let i=1;i<a.length-1;i++){
        temp[j++]=a[i]
    }
    console.log(temp);
    return a[0];
}

console.log(shiftArray(arr));