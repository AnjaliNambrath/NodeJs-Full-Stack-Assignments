arr=[1,2,3,4,5]
function pushArray(arr,val) {
    arr[arr.length]=val;
    return arr.length;
}
console.log(pushArray(arr,12));
console.log(arr);