var arr=[4,3,1,5,2]
function sortArray(a) {
    for(let i=0;i<a.length;i++){
        for(let j=i+1;j<a.length;j++){
            if(a[j]<a[i]){
                let temp = a[i];
                a[i]=a[j];
                a[j]=temp;
            }
        }
    }
    return arr;
}

console.log(sortArray(arr));