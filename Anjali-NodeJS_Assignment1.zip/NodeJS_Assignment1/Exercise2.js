// var a = Math.random().toString(36).slice(2);
const fs = require('fs')
// const random = require('random-string-alphanumeric-generator');
var arr=[]
for(let i=0;i<100;i++){
    var data = Math.random().toString(36).slice(2)+"\n"+data
    fs.writeFile('./lib/random-words.txt', data , (err) => {
        if (err) throw err;
    })
}
console.log("Random words added to file successfully!");