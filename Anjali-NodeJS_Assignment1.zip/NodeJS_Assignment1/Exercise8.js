const excel = require('xlsx')

const file = excel.readFile('./lib/userToExcel.xlsx')

var users = [
  { name: 'Anjali', age: 24, gender: 'Female', city: 'Kerala' },
  { name: 'Arun', age: 23, gender: 'Male', city: 'Karnataka' },
  { name: 'Sam', age: 19, gender: 'Male', city: 'Goa' },
  { name: 'Babu', age: 25, gender: 'Male', city: 'Hyderabad' },
  { name: 'Hima', age: 34, gender: 'Female', city: 'Kerala' },
  { name: 'Arjun', age: 29, gender: 'Male', city: 'Goa' }
]

const ws = excel.utils.json_to_sheet(users)

excel.utils.book_append_sheet(file,ws,"Sheet2")

excel.writeFile(file,'./lib/userToExcel.xlsx')
