const fs = require('fs')

var user = [{"name":"Anjali","age":"25","gender":"Female","city":"Kerala"},
{"name":"Sravan","age":"28","gender":"Male","city":"Karnataka"},
{"name":"Anjana","age":"21","gender":"Female","city":"Goa"},
{"name":"Sam","age":"23","gender":"Male","city":"Mumbai"},
{"name":"Priya","age":"29","gender":"Female","city":"Manipur"},
{"name":"Manisha","age":"21","gender":"Female","city":"Kerala"},
{"name":"Ram","age":"27","gender":"Male","city":"Goa"}]

    var heading = "Name | Age | Gender | City\n"
    var body =""
    for(let i=0;i<user.length;i++){
        body+=user[i].name+" | "+user[i].age+" | "+user[i].gender+" | "+user[i].city+"\n"
    }
    new_content = heading + body
    fs.writeFile('./lib/user-info.txt', new_content, 'utf8', function(err) {
        if (err) {
            throw err;
        }
        console.log('The file have been updated!');
    });
