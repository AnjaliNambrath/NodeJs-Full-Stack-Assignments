const fs = require('fs')

fs.readFile('./lib/userDetails.txt','utf8', function(err, result) {
    var data = result.split('\r\n').map(function(el){
         return el.split(/[|]/); 
        });
    // console.log(data);
    var head = data.shift();
    // console.log(head)
    var obj = data.map(function (el) {
    var obj = {};
    for (var i = 0, n = el.length; i < n; i++) {

        obj[head[i]] = el[i];
        // console.log(obj);
    }
    return obj;
});
var jsonObj = JSON.stringify(obj)
console.log("########Printing in JSON Format#########");
console.log(jsonObj);
})