const fs = require('fs')

function getFileContent(file) {
    // filePath = path.join(__dirname, './lib/'+file);
    fs.readFile('./lib/'+file,'utf-8',(err,data) =>{
        console.log(data);
    });
    console.log('Reading file...:'+file);
}

getFileContent('readme.txt')
getFileContent('student.csv')
getFileContent('index.html')
