const fs = require('fs');

fs.copyFile('./lib/readme.txt', './lib/myfile.txt', (err) => {
  if (err) throw err;
  console.log('File is copied to destination');
});