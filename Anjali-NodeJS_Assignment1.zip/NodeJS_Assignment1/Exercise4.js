const { log } = require('console');
const fs = require('fs')

fs.readFile('./lib/debug.log','utf8', function(err, result) {

    if (err){
        throw err;
    }
    // console.log(result);
    var lines = result.split("\r\n")
    console.log(lines);

    var new_content = lines.map(function(line) {
        return "["+ new Date().toLocaleString('en-IN', { day:"2-digit",year:"numeric",month:"short",hour:"2-digit",minute:"2-digit",second:"2-digit",hours12:true,timeZone:"Asia/Kolkata" }).toUpperCase()+"] "+line;
    }).join("\r\n")

    fs.writeFile('./lib/debug.log', new_content, 'utf8', function(err) {
        if (err) {
            throw err;
        }
        console.log('The file have been updated!');
    });
});