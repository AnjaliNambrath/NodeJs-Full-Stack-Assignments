url = 'mongodb://localhost:27017/SampleFSD'
module.exports = url