const mongoose = require('mongoose')

const userSchema = new mongoose.Schema(
    {
        name:{
            type:String,
            trim:true,
            required:[true,"Name is Required"]
        },
        age:{
            type:Number,
            trim:true,
            required:[true,"Age is Required"]
        }
    }
)

module.exports = mongoose.model("User",userSchema)