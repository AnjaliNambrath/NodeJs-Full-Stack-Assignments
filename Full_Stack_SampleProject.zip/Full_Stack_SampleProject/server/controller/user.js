const users = require('../model/user')

exports.createUser = async (req,res)=>{
    try{
        const addUser = await users.create(req.body)
        console.log("User Added Successfully");
        res.status(200).json(addUser)
    }
    catch(error){
        console.error("Error")
        res.status(500).send("Error")
    }
}

exports.getAllUser = async(req,res)=>{
    try{
        const getUser = await users.find({})
        res.send(getUser)
    }
    catch(err){
    console.error('Error getting user', err);
    res.status(500).send('Error getting user');
  } 
}