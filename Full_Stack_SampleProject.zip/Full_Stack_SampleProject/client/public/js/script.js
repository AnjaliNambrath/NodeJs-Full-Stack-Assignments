window.onload = display;

function addUser(){
    console.log("Hai");
    var cname = document.getElementById('name').value;
    var cage = document.getElementById('age').value;
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function(){
        if(this.readyState==4){
            if(this.status==200){
                alert("User Added Successfully!!!")
            }
        }
    }
    xhttp.open("POST","http://localhost:5000/user",true)
    xhttp.setRequestHeader("Content-type","application/json")
    xhttp.send(JSON.stringify({name:cname,age:cage
    }))
    event.preventDefault();
}
var users_json ="";
function display(){
    var content ="";
    var htt = new XMLHttpRequest();
    htt.onreadystatechange = function(){
        if(this.readyState==4){
            if(this.status==200){
                res = this.responseText
                users_json=JSON.parse(res)
                for(let u in users_json){
                    var usr = `<div><p>NAME:"${users_json[u].name}"<p/><p>AGE:"${users_json[u].age}"<p/></div>`
                    content=usr+content
                }
                var element = document.getElementById('root')
                element.innerHTML = content;
            }
        }
    }
    htt.open("GET","http://localhost:5000/user",true)
    htt.send();
}