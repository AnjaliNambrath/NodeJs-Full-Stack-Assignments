function fetchExm() {
    fetch("https://64ed8ffb1f87218271416236.mockapi.io/api/xml/userdata").then((res)=> {
    return res.json();
    console.log(res);
}).then((res)=> {
    console.log(res);
    document.getElementById('container').innerHTML = JSON.stringify(res);
});
}




