var arr=[12,34,45,53,55,43,11]
var n= arr.length
var i=1;
while(i<n){
    let key=arr[i]
    let j= i-1
    while(j>=0 && key<arr[j]){
        arr[j+1] = arr[j]
        j=j-1
    }
    arr[j+1]=key
    i++
}
console.log(arr)