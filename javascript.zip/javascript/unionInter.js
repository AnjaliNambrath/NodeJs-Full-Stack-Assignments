let arr1=[1,3,4,5,7]
let arr2=[2,3,5,6]

let resarr = []
arr1 =arr1.concat(arr2);
var k=0
for(let i=0;i<arr1.length;i++){
    var flag = 0;
    for(let j=0;j<resarr.length;j++){
        if(arr1[i]==resarr[j]){
            flag =1
            break
        }
    }
    if(flag ==0){
        resarr[k]=arr1[i]
        k++
    }
}

console.log(resarr.sort().join());