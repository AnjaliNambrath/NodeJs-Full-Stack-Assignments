let arr=[1,4,6,9,5,2,7,8,10];
let arr2=[];

let l=arr.length;
for(let i=0;i<l;i++){
        let k=arr[i]-1;
        arr2[k]=arr[i]
    }        
    for(let j=0;j<arr2.length;j++){
        if(arr2[j]==null){
            console.log(j+1)
        }
    }