//var a = [15,11,12,13,11,12,12,15]
var a= [11,11,11,12,11,12,12]
//var b=[]
//k=0
for(var i=0;i<a.length;i++){
    for(var j=i+1;j<a.length;j++){
        if(a[i]==a[j] && a[j]!=0){
            console.log(a[i]);
            //b[k]=a[j]
            //k++;
            while((a[i]==a[j]) && j<a.length){
            a[j]=0;
            j++;
            }
            a[i]=0;
        }
    }
}
//console.log(b);