var bday = [15,11,12,13,11,12,12,15]
let map = new Map();
for(let i=0;i<bday.length;i++){
    if(map.has(bday[i])){
        let val = map.get(bday[i])
        map.set(bday[i],val+1)
    }else{
        map.set(bday[i],1)
    }
}

let sharedbday=[]
let max=0;
let maxbday=0;
for(let [key,val] of map.entries()){
    if(val>max){
        max=val;
        maxbday=key;
        
    }
    // if(val>1){
    //     sharedbday.push(key)
    // }
}
//console.log(sharedbday);
console.log(max+" persons has Birth date :"+maxbday);
console.log(map.get(maxbday));
