//get key from object


let users ={

    name : "Anjali",

    age : 23,

};


var a=Object.keys(users)[0]


console.log(a)



//get key from array of objects




let user =[{
    name : "Anjali",
    age : 23,
},{
  name : "Anj",
    age : 26,  
}];

const keys = Object.keys(user[0]);
console.log(keys[0]);
for(let k in keys){
    console.log(keys[k]);
}

// const array = [
//   {name: 'Amit', age: 30},
//   {name: 'Ajay', age: 25},
//   {name: 'Ankit', age: 35}
// ];

// // get the keys from first object in array
// const keys = Object.keys(array[0]);
// console.log(keys);

// for(let k in keys){
//     console.log(keys[k]);
// }

// console.log(`Keys: ${keys}`);

//closure
function test(){
return function(){
return "Hai";
}}
test()();
'Hai'


function add(x){
return function(y,z){
return function(a){
return x+y+z+a;
}
}
}
add(10)(20,30)(40);
'Hai'
