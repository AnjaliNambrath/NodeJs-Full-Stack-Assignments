let count=0;
const arr =[12,34,12,53,12,43,12] 
for(var i=0;i<arr.length;i++){
    if(arr[i]==12){
        count++;
    }
}
console.log(count);
