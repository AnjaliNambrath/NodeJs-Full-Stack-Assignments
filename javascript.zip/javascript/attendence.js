let arr=[1,4,6,9,5,2,7,8,10];

for(let i=1;i<=10;i++){
    var flag=0;
    for(let j=0;j<10;j++){
        if(arr[j]==i){
            flag=1
        }        
}
if(flag==0){
    console.log(i)
    break;
}
}
