var arr=[12,34,45,53,55,43,11]
var n= arr.length
var i=0;
function swap(arr,i,j) {
    let temp = arr[i];
    arr[i]=arr[j]
    arr[j]=temp
}
while (i<n-1) {
    m=i;
    j=i+1
    while(j<n){
        if(arr[j]<arr[m]){
            m=j
        }
        j++
    }
    swap(arr,i,m)
    i++
}

console.log(arr)