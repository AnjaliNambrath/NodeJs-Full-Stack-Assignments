let arr=[74,98,74,86,100,24,43,17];

let n=arr.length;

let j=n-1;

let i=0;

while(i<=j){

    if(arr[i]<73 ){

        let temp;
        temp=arr[i];

        arr[i]=arr[j];

        arr[j]=temp;

        i++;

        j--;

 

    }

    else{

        i++;

    }

}

console.log(arr);