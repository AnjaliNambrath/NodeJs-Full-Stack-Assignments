var name="anjali";
var tempArr=[]
var arrname=name.split("");
console.log(arrname);
var size=arrname.length;
var j=size;
for(var i=0;i<size;i++){
    tempArr[j-1]=arrname[i]
    j--; 
}
console.log(tempArr.join(""));