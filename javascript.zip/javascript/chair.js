let arr=[10,20,30,40,50]
let k=2
n=arr.length;
let tempArr=[]
let i=n-1
let p=0;
while (i>n-k-1) {
    tempArr[p]=arr[i]
    i--;
    p++;
}
let e=n-k-1;
while (e>=0) {
    arr[e+k]=arr[e]
    e--;
}
let z=k-1;
let x=0;
while (z>=0) {
    arr[z]=tempArr[x]
    x++
    z--
}
console.log(arr);