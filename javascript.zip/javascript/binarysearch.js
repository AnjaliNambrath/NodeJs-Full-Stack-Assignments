// var arr = [];
// var size = 10
// console.log("Enter 10 Elements");
// for(var i=0;i<size;i++){
//     arr[i]=prompt('Enter Element '+(i+1));
// }
// key=prompt('Enter the element to find');
const arr =[12,34,45,53,78,43,99] 



function binarySearch(arr,key) {
    var start = 0;
    var end = arr.length-1;
    while (start<=end) {
        var mid = Math.floor((start+end)/2);
        if(arr[mid]==key){
            return ("Key found on index: "+mid);
        }
        else if(arr[mid]<key){
           start=mid+1; 
        }else{
            end=mid-1;
        }
    }
    return "Key not found";
}

console.log(binarySearch(arr,99));