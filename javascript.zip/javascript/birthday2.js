//console.log("1","12")
var bday = [15,11,12,13,11,12,12,15]
let map = new Map();
for(let i=0;i<bday.length;i++){
    if(map.has(bday[i])){
        let val = map.get(bday[i])
        map.set(bday[i],val+1)
    }else{
        map.set(bday[i],1)
    }
}

let sharedbday=[]
for(let [key,val] of map.entries()){
    if(val>1){
        sharedbday.push(key)
    }
}
console.log(sharedbday);