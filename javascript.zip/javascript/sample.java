public static void main(String[] args){
        System.out.println("Hello World");
        int n = 9, nIndex = n/2 + 1;
        System.out.println(nIndex);
        for(int i = 0; i < nIndex; i++){
            for(int j = 0; j <= n; j++){
                if((j <= nIndex + i) && (j >= nIndex - i)){
                    System.out.print(j);
                }
                else{
                    System.out.print(" ");
                }
            }
            System.out.println();
        }
        for(int i = n -1; i >= nIndex; i--){
            for(int j = 0; j < n; j++){
                if((j <= i ) && (j > n - i)){
                    System.out.print(j);
                }
                else{
                    System.out.print(" ");
                }
            }
            System.out.println();
        }
        return;
    }