var arr=[1,2,3,4,5]
var tempArr=[]
var size=arr.length;
var j=size;
for(var i=0;i<size;i++){
    tempArr[j-1]=arr[i]
    j--;
}
console.log(tempArr);
