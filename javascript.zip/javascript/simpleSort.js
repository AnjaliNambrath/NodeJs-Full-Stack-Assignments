let arr =[12,34,45,53,55,43,11]
let n=arr.length;

let k=0
function swap(arr,i,j) {
    let temp = arr[i];
    arr[i]=arr[j]
    arr[j]=temp
}
while(k<n){
    let i=0,j=1;
    while(j<n-k){
        if(arr[i]>arr[j]){
            swap(arr,i,j)
        }
        i++
        j++
    }
    k++
}
console.log(arr)