function countPairsWithSumK(arr, K) { //Don't change the number of parameters
    // Please write your code here
    var count = 0;
    var str = []
    for(let i=0;i<arr.length;i++){
        //var str=[]
        //var tot=0
        for(let j=i+1;j<arr.length;j++){
            //tot = Math.abs(tot+arr[j]);
            //str.push(arr[j]);
            if(arr[i]+arr[j]==K){
                count++;
            }
        }
    }
    //console.log(str)
    return count
}

//Please don't modify the below code

(function () {
    const arr = process.argv[2].split(" ").map(Number);

    console.log(countPairsWithSumK(arr, parseInt(process.argv[3])));
})()