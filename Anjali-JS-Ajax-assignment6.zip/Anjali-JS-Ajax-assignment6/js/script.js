var xhttp;
var res_json;
var userPlus;
var userEdit;
var addModal;
var updateModal;
window.onload = function(){
    fetchUser();
    userPlus = document.getElementById("addUser");
    addModal = document.getElementById("modalAddUser");
    updateModal = document.getElementById("modalUpdateUser");
    userPlus.addEventListener("click", () => {
        addModal.classList.add("show");
        addModal.style.display = "block";
    })
  
    window.addEventListener("click", (event)=> {
        if (event.target == addModal) {
          addModal.style.display = "none";
        }
    });
    window.addEventListener("click", (event)=> {
        if (event.target == updateModal) {
          updateModal.style.display = "none";
        }
    });

}

// function clearform() {
// 	document.getElementById('upinputName').value=""
// 	document.getElementById('upinputAge').value="";
// 	document.getElementById('upinputState').value="";
// }

function fetchUser() {
    xhttp = new XMLHttpRequest();
    
    xhttp.onreadystatechange =function () {
        
        if(this.readyState == 4){
            if(this.status == 200){
            res_json = this.responseText;
            res=JSON.parse(res_json);
            loadUser(res);
            
        }
    }
    };
    xhttp.open("GET","https://6503d4d9c8869921ae243091.mockapi.io/users",true)
    xhttp.send();
};

function loadUser(res) {
    var content = `<tr id="tableHeadings">
                <th class="name">Name</th>
                <th class="age">Age</th>
                <th class="state">State</th>
                <th class="functions">Functions</th>
            </tr>`;
    for(let i in res){
            // console.log(res[i].id);
            content+=`<tr class="user" id="${res[i].id}">
                <td class="name">${res[i].name}</td>
                <td class="age">${res[i].age}</td>
                <td class="state">${res[i].state}</td>
                <td class="functions">
                    <button class="edit" onclick="editUser(${res[i].id});" type="button" id="${res[i].id}"><i class="fa-solid fa-pen-clip"></i></button><button class="deleteB" onclick="deleteUser(${res[i].id});"type="button" id="${res[i].id}"><i class="fa-solid fa-trash-can"></i></button>
                </td>
            </tr>`
            // console.log(res_json);
            }
            document.getElementById('table').innerHTML=content;
}
function addUser() {
    var username = document.getElementById('inputName').value;
	var age = document.getElementById('inputAge').value;
	var state = document.getElementById('inputState').value;
    if(username==='' || age==='' || state==="State"){
		alert("Provide All the Details!!!")
		return;
	}
    xhttp = new XMLHttpRequest();
 
    xhttp.onreadystatechange =function () {
        console.log(this.readState);
        console.log(this.status);
        if(this.readyState == 4){
            if(this.status == 201){
                //  console.log(this.responseText);
                document.getElementById('addUserForm').reset();
                 addModal.style.display = "none";
                
                fetchUser();
            }
        }
    };
    xhttp.open("POST","https://6503d4d9c8869921ae243091.mockapi.io/users",true)
    xhttp.setRequestHeader("Content-type","application/json")
    xhttp.send(JSON.stringify({
		id:res_json.length+1,
		name: username,
		age:age,
		state: state,
	}));
    // console.log(res_json);
}
var USERID;
function editUser(edid){
    USERID=edid
    userEdit = document.getElementById("updateUser");
    updateModal = document.getElementById("modalUpdateUser");
    updateModal.classList.add("show");
    updateModal.style.display = "block";
    var upind = res.findIndex(e=> e.id==edid)
    document.getElementById('upinputName').value = res[upind].name;
	document.getElementById('upinputAge').value= res[upind].age;
	document.getElementById('upinputState').value= res[upind].state;
}

function updateUser() {
    var upname = document.getElementById('upinputName').value;
	var upage = document.getElementById('upinputAge').value
	var upstate = document.getElementById('upinputState').value;
	if(upname==='' || upage==='' || upstate==="State"){
		alert("Provide All the Details!!!")
		return;
	}
    xhttp = new XMLHttpRequest();
 
    xhttp.onreadystatechange =function () {
        if(this.readyState == 4){
            if(this.status == 200){
                //  console.log(this.responseText);
                 updateModal.style.display = "none";
                fetchUser();
            }
        }
    };
    xhttp.open("PUT","https://6503d4d9c8869921ae243091.mockapi.io/users/"+USERID,true)
    xhttp.setRequestHeader("Content-type","application/json")
    xhttp.send(JSON.stringify({
		name: upname,
		age:upage,
		state: upstate,
	}));
}

function deleteUser(usrid){
        // var delind = res_json.findIndex(e=> e.id==usrid);
        var modal = document.getElementById("deleteModal");
        modal.classList.add("show");
        modal.style.display = "block";
        var cancelDelete=document.querySelectorAll(".deleteCancel");
        cancelDelete.forEach((btn)=>{
            btn.addEventListener("click", ()=>{
                modal.style.display = "none";
            });
        });
        var confirmDelete = document.querySelector(".confirmDelete");
        confirmDelete.addEventListener("click", ()=>{
            modal.style.display = "none";
            xhttp.open("DELETE","https://6503d4d9c8869921ae243091.mockapi.io/users/"+usrid,true)
            xhttp.setRequestHeader("Content-type","application/json")
            xhttp.send();
        });
        console.log(usrid);
        var delnm;
        for(let i in res){
            if(res[i].id==usrid){
                delnm=res[i].name
                console.log(delnm)
                document.getElementById('userDeleted').innerHTML=delnm
                break;
            }
        }
        xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange =function () {
            if(this.readyState == 4){
                if(this.status == 200){
                    fetchUser();
                }
            }
        };   
}

