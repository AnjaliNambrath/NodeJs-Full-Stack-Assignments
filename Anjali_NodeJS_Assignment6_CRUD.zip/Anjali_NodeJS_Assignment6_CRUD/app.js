const express = require('express');
const mongoose = require("mongoose");
const bodyParser = require('body-parser');
const routes = require('./routes/payment');
require("colors")
// const url = 'mongodb://localhost:27017/CRUDAssignment'
const url = require('./config/config')

const app = express();
const port = 3000;

//DB Connection
mongoose.connect(url)
console.log("Mongo connection successful..".yellow.underline.bold);

app.use(bodyParser.json());
app.use(routes);

//Listening to server
app.listen(port, () => {
  console.log('Application listening on port 3000'.red.underline.bold);
});