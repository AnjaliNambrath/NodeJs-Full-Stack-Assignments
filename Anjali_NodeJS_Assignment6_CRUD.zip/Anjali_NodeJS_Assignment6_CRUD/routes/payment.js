const express = require('express');
const router = express.Router();
const paymentController = require('../controller/payment');

//Define routes
router.get('/payment', paymentController.getAllPayment);
router.post('/payment', paymentController.createPayment);
router.get('/payment/:_id', paymentController.getPaymentById);
router.put('/payment/:_id', paymentController.updatePayment);
router.delete('/payment/:_id', paymentController.deletePayment);

module.exports = router;
