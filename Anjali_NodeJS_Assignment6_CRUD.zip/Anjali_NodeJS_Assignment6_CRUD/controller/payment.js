const Payment = require('../models/payment');

//Add Payment to DB
exports.createPayment = async (req,res)=>{
  try{
    const payCreate = await Payment.create(req.body)
    res.status(200).json({message:"Payment Added successfully",AddedPayment:payCreate}) 
  }catch(err){
    console.error('Error creating payment', err);
    res.status(500).send('Error creating payment');
  }
}

//Get All Payment from DB
exports.getAllPayment = async (req, res) => {
  try{
    const paydetails= await Payment.find({});
    res.send(paydetails)
  }catch(err){
    console.error('Error getting payment', err);
    res.status(500).send('Error getting payment');
  } 
};

//Get Payment By Id from DB
exports.getPaymentById = async (req, res) => {
  const customerId = req.params._id;
  try{
    const paydetailsByid= await Payment.findById(customerId);
    res.send(paydetailsByid)
  }catch(err){
    console.error('Error getting payment', err);
    res.status(500).send('Error getting payment');
  } 
};

//Update the Payment
exports.updatePayment = async (req, res) => {
  const cId = req.params._id;
  const updatedPayment = req.body;

  try{
    const options={new:true}
    const updateByid= await Payment.findByIdAndUpdate(cId,updatedPayment,options);
    res.send({message:"Payment Updated successfully",updatedayment:updateByid})
  }catch(err){
    console.error('Error updating Payment', err);
      res.status(500).send('Error updating Payment');
  }
};

//Delete the Payment details
exports.deletePayment = async (req, res) => {
  const custId = req.params._id;
  try{
    const paydetailsByid= await Payment.findByIdAndDelete(custId);
    res.send({message:'Payment deleted successfully',deletePayment:paydetailsByid});
  }catch(err){
    console.error('Error deleting payment', err);
    res.status(500).send('Error deleting payment');
  } 
};

