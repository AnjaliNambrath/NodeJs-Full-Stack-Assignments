const url = 'mongodb://localhost:27017/CRUDAssignment'
module.exports = url