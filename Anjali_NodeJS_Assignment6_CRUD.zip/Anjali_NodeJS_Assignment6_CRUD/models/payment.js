const mongoose = require("mongoose");

const paymentSchema = new mongoose.Schema(
  {
    customer_id: {
      type: String,
      trim: true,
      required: [true, "CustomerID is required"]
    },
    amount: {
      type: Number,
      trim: true,
      required: [true, "Amount is required"]
    },
    payment_date: {
      type: String,
      trim: true,
      required: [true, "Payment_date is required"]
    },
    payment_method: {
      type: String,
      trim: true,
      required: [true, "Payment_method is required"]
    },
    status: {
      type: String,
      trim: true,
      required: [true, "Status is required"]
    },
    invoice_number: {
      type: String,
      trim: true,
      required: [true, "Invoice_number is required"]
    },
    transaction_id:{
        type: String,
        trim: true,
        required: [true, "Transaction_ID is required"]
    },      
    card_type:{
        type: String,
        trim: true, 
        required: [true, "Card_type is required"]
    },
    card_number:{
        type: String,
        trim: true, 
        required: [true, "Card_number is required"]
    }
  },
    {
        versionKey: false, 
    }
);

module.exports = mongoose.model("payment", paymentSchema);
